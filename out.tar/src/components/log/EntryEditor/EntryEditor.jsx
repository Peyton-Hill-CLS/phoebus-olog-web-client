/**
 * Copyright (C) 2019 European Spallation Source ERIC.
 * <p>
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * <p>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * <p>
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
import { useEffect, useRef } from "react";
import { Button, Stack, Typography } from "@mui/material";
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { Description } from "./Description";
import { TextInput } from "components/shared/input/TextInput";
import LogbooksMultiSelect from "components/shared/input/managed/LogbooksMultiSelect";
import TagsMultiSelect from "components/shared/input/managed/TagsMultiSelect";
import EntryTypeSelect from "components/shared/input/managed/EntryTypeSelect";
import { PropertyCollectionInput } from "components/shared/input/managed/PropertyCollectionInput";
import { ologApi } from "src/api/ologApi";
import { OperatorShiftSummary } from "components/log/OperatorShiftSummary/OperatorShiftSummary";

export const EntryEditor = ({
  form,
  title,
  onSubmit,
  onCancel,
  renderDateTime,
  submitDisabled,
  attachmentsDisabled
}) => {
  const topElem = useRef();
  const { control, handleSubmit, formState, setValue, getValues } = form;

  const { data: levels } = ologApi.endpoints.getLevels.useQuery();
  const defaultLevel = levels?.find((level) => level?.defaultLevel);

  const { data: logbooks = [], isLoading } =
    ologApi.endpoints.getLogbooks.useQuery();
  const defaultLogbook = logbooks?.find((logbook) => logbook?.defaultLogbook);

  useEffect(() => {
    if (!attachmentsDisabled) {
      setTimeout(() => {
        setValue("level", defaultLevel?.name);
        if(typeof defaultLogbook !== 'undefined') {
          setValue("logbooks", [defaultLogbook]);
        }
      }, 0);
    }
  }, [defaultLevel, setValue, attachmentsDisabled]);

  // Scroll to top if there are field errors
  useEffect(() => {
    if (Object.keys(formState.errors).length > 0) {
      if (
        topElem.current &&
        typeof topElem.current.scrollIntoView === "function"
      ) {
        topElem.current.scrollIntoView({ behavior: "smooth" });
      }
    }
  }, [formState]);

  return (
    <Stack
      gap={1}
      px={4}
      pb={4}
      pt={2}
      maxWidth="1000px"
      margin="0 auto"
      width="100%"
      height="fit-content"
      sx={{ backgroundColor: "ologBackground.main" }}
    >
      <Typography
        component="h2"
        variant="h3"
        fontSize="2rem"
        py={1}
      >
        {title}
      </Typography>
      <Stack
        component="form"
        onSubmit={handleSubmit(onSubmit)}
        gap={2}
      >
        <span ref={topElem} />
        <LogbooksMultiSelect
          control={control}
          rules={{
            validate: {
              notEmpty: (val) =>
                val?.length > 0 || "Select at least one logbook"
            }
          }}
        />
        <TagsMultiSelect control={control} />
        <EntryTypeSelect
          rules={{
            validate: {
              notEmpty: (val) =>
                val?.length > 0 || "Please select an Entry Type"
            }
          }}
          control={control}
        />
        <TextInput
          name="title"
          label="Title"
          control={control}
          defaultValue=""
          rules={{
            required: {
              value: true,
              message: "Please specify a title."
            }
          }}
        />
        {renderDateTime &&
        <DateTimePicker
          form={form}
          name="date"
          onChange={(value, context) => setValue("date", value._d.getTime())}
          label="Optional Date & Time" 
	  sx={{
	    '& .MuiOutlinedInput-notchedOutline': { borderColor: 'ologLine.main' },
	    '&:hover .MuiOutlinedInput-notchedOutline': {borderColor: 'ologDarkLine.main'},
	  }}
		/>}
        <OperatorShiftSummary
          control={control}
          form={form}
          disabled={!renderDateTime || (getValues("level") != "Shift Summary")}
          />
        <Description
          form={form}
          attachmentsDisabled={attachmentsDisabled}
        />
        <PropertyCollectionInput control={control} />
        <Button
          type="submit"
          variant="contained"
          disabled={submitDisabled}
	  sx={{
              "&.Mui-disabled": {
                background: "ologDisabled.main",
                color: "ologLine.main"
              }
            }}
        >
          Submit
        </Button>
        <Button
          type="cancel"
          variant="contained"
          color="ologRed"
          sx={{ marginBottom: 4 }}
          onClick={onCancel}
        >
        Cancel
        </Button>
      </Stack>
    </Stack>
  );
};
